# GUITAR ACADEMY — MATRIZ MESTRA V1.0
**Status:** especificação-base consolidada  
**Idioma:** Português brasileiro  
**Profundidade:** Conservatório  
**Certificação:** por nível e por curso  
**Regra desta entrega:** planejamento e fundação de domínio; não substituir módulos existentes sem auditoria.

## 1. Propósito e identidade
A Guitar Academy é uma plataforma de formação musical estruturada, do absoluto iniciante à especialização, para cinco instrumentos: violão, guitarra, baixo, teclado e bateria. Deve unir rigor acadêmico, prática instrumental real, repertório, autonomia e performance.

A formação é universal. O repertório pode contemplar música brasileira e regional, popular, pop, rock, jazz, blues, música clássica, gospel e música cristã, sem limitar a identidade da academia a um único gênero.

## 2. Princípios de produto
- Instrumento físico no centro da aprendizagem; interfaces virtuais são apoio, não substituição.
- Uma tela = uma missão clara.
- Priorizar estabilidade, velocidade e simplicidade premium.
- Online-first: a experiência principal depende de conexão; preservar rascunhos e operações temporárias quando possível, sem prometer modo offline completo.
- Professor IA como tutor auxiliar; não cria currículo oficial, não aprova competências e não emite certificados.
- Conteúdo publicado precisa de revisão e aprovação docente.
- Não confundir tempo com aplicativo aberto com prática musical efetiva.

## 3. Instrumentos e níveis
Instrumentos: `violao`, `guitarra`, `baixo`, `teclado`, `bateria`.

Níveis:
- 0 — Fundamentos
- 1 — Iniciação
- 2 — Desenvolvimento básico
- 3 — Intermediário
- 4 — Avançado
- 5 — Especialização e performance

A estrutura é de seis níveis por instrumento. A quantidade de módulos e aulas poderá variar após o desenho pedagógico detalhado; a convenção inicial de seis módulos por nível é uma referência de planejamento, não uma obrigação artificial.

## 4. Dez eixos de formação
1. Teoria e linguagem musical.
2. Percepção e treinamento auditivo.
3. Leitura e escrita musical.
4. Técnica instrumental e ergonomia.
5. Ritmo, pulsação, subdivisão e métrica.
6. Harmonia aplicada e análise.
7. Repertório e interpretação.
8. Improvisação, composição e arranjo.
9. Prática de conjunto e colaboração.
10. Performance, gravação e produção.

Os eixos comuns devem ser contextualizados em cada instrumento. Leitura inclui partitura, cifras, tablatura ou notação específica conforme o instrumento e o objetivo.

## 5. Núcleo comum e núcleo instrumental
### Núcleo comum
Teoria, percepção, leitura, ritmo, harmonia, análise, apreciação musical, composição e prática de conjunto.

### Núcleo especializado
Técnica, ergonomia, vocabulário, repertório, recursos expressivos, equipamentos e performance próprios de cada instrumento.

Evitar duplicar conteúdos idênticos entre cursos quando uma disciplina comum puder ser compartilhada. A aplicação prática, porém, deve ser específica para o instrumento.

## 6. Currículo já planejado
### Nível 0 — Fundamentos
- Violão: anatomia, postura, afinação, ataque, pulsação, primeiras sequências.
- Guitarra: instrumento e sinal, postura, palheta, afinação, coordenação, tablatura e riffs iniciais.
- Baixo: anatomia, postura, afinação, alternância dos dedos, pulsação e primeiras linhas.
- Teclado: geografia das teclas, postura, dedilhado, notas, tons/semitons e primeiras melodias.
- Bateria: peças, postura, baquetas, ataques, pulsação, coordenação inicial e groove básico.

### Nível 1 — Iniciação
- Violão: acordes básicos, trocas, ritmos, dedilhados, cifras e músicas completas simples.
- Guitarra: palhetada, coordenação, riffs, power chords, timbre e primeiras músicas.
- Baixo: notas, figuras rítmicas, escalas iniciais, acompanhamento e linhas simples.
- Teclado: dedilhado, escalas maiores, tríades, acordes e acompanhamento.
- Bateria: rudimentos básicos, coordenação, grooves, chimbal, viradas simples e repertório.

### Nível 2 — Desenvolvimento básico
- Violão: campo harmônico maior, inversões, pestana, ritmos brasileiros, arpejos, escalas e transposição.
- Guitarra: pentatônica, bends, vibrato, slide, power chords, legato e improvisação inicial.
- Baixo: escalas, arpejos, construção de linhas, síncopes, groove e repertório estilístico.
- Teclado: campo harmônico, inversões, independência das mãos, acompanhamento, menor natural e repertório.
- Bateria: rudimentos, subdivisões, independência, grooves estilísticos, viradas e repertório.

### Nível 3 — Intermediário
- Violão: campo menor, funções e cadências, tétrades, tensões, condução de vozes, fingerstyle, arranjos e improvisação.
- Guitarra: intervalos, escalas, harmonia funcional, pentatônica em cinco posições, modos, técnica e improvisação/composição.
- Baixo: intervalos, funções, tétrades, cromatismos, groove avançado, estilos e criação de linhas.
- Teclado: harmonia funcional, campo menor, tétrades, tensões, voicings, leitura, arranjos e improvisação.
- Bateria: independência, rudimentos, dinâmica, métricas simples/compostas, estilos, improvisação e interação com banda.

### Nível 4 — Avançado
- Violão: harmonia avançada, rearmonização, fingerstyle avançado, acompanhamento complexo, improvisação e arranjos.
- Guitarra: picking avançado, legato, sweep/tapping, harmonia aplicada, improvisação avançada, timbre e interpretação.
- Baixo: harmonia avançada, condução, groove e polirritmia, slap/tapping, vocabulário estilístico e arranjos.
- Teclado: harmonia expandida, voicings, rearmonização, independência, improvisação e arranjos.
- Bateria: rudimentos avançados, independência, polirritmia, dinâmica, linguagens estilísticas e improvisação.

### Nível 5 — Especialização e performance
- Violão: composição, fingerstyle de especialização, contraponto, improvisação, identidade interpretativa, arranjo solo e performance.
- Guitarra: linguagem avançada, improvisação, técnica de alta performance, composição, timbre/produção e performance.
- Baixo: harmonia especializada, improvisação, técnicas avançadas, composição de linhas, performance em conjunto e produção.
- Teclado: harmonia especializada, voicings, composição, arranjos, improvisação e performance.
- Bateria: vocabulário rítmico avançado, técnica especializada, improvisação, composição rítmica, performance coletiva e produção.

Os módulos detalhados, aulas, pré-requisitos e critérios instrumentais precisam ser revisados por docente antes de publicação. Conteúdos como sweep picking, slap, contraponto, polirritmia e voicings avançados exigem pré-requisitos explícitos.

## 7. Modelo pedagógico de aula
Cada aula deve definir:
1. Objetivo de aprendizagem observável.
2. Pré-requisitos.
3. Fundamentação teórica aplicada.
4. Demonstração.
5. Estudo orientado.
6. Prática com instrumento físico.
7. Aplicação em repertório.
8. Erros comuns e correções.
9. Desafio prático.
10. Autoavaliação.
11. Evidência/registro, quando aplicável.
12. Competências relacionadas e tempo sugerido.

Assistir ao vídeo, isoladamente, não deve significar domínio. A conclusão da aula deve respeitar a atividade definida para ela.

## 8. Progressão e desbloqueio
- Os cinco instrumentos aparecem desde o início.
- O aluno escolhe um primeiro curso.
- Os demais cursos ficam bloqueados até o aluno atingir 50% de progresso válido no primeiro curso.
- Progresso válido: aulas e atividades obrigatórias efetivamente concluídas.
- Não exigir aprovação docente em todas as aulas para liberar os cursos.
- Progresso, domínio e conclusão acadêmica são conceitos distintos.
- Cada curso mantém progresso e histórico independentes.

## 9. Avaliação
Avaliações oficiais são práticas. A teoria é ensinada e verificada pela aplicação musical, sem depender de prova escrita.

Fluxo: desafio → preparação → gravação/arquivo → envio → análise docente → aprovação ou correção → feedback → nova tentativa.

Evidências aceitas: gravação de áudio, gravação de vídeo e arquivo previamente gravado. Feedback docente: texto, áudio e vídeo demonstrativo. Preservar todas as tentativas e seus históricos.

Estados: não iniciada, em preparação, enviada, em análise, aprovada, necessita correção e nova tentativa enviada.

Dimensões: técnica, ritmo, musicalidade, aplicação teórica, repertório e autonomia. Critérios devem ser específicos por instrumento, competência e nível.

Estados de competência:
- Não iniciado.
- Em desenvolvimento.
- Aguardando avaliação.
- Necessita correção.
- Dominado (somente após aprovação docente).

Autoavaliação não equivale a domínio. Professor pode apontar trechos da gravação se o recurso técnico permitir.

## 10. Certificação
- Certificados individuais por nível.
- Certificado final por curso/instrumento.
- Exigir conteúdo obrigatório concluído, atividades e avaliações práticas aprovadas e aprovação final do professor.
- Incluir nome do aluno, instrumento/curso, nível, data, identidade da academia, identificador único e mecanismo de validação.
- Diferenciar certificado de participação, certificado de nível e certificado de conclusão.
- Conquistas automáticas não substituem certificação acadêmica.

## 11. Usuários e permissões
Papéis: aluno, professor e professor principal.
- Alunos são vinculados automaticamente à academia no cadastro.
- Cadastro: Google ou e-mail/senha.
- Professor principal tem acesso global.
- Professores adicionais podem ter acesso restrito a alunos e grupos atribuídos.
- Permissões devem ser verificadas no backend/regras Firebase; nunca depender de botão oculto, senha embutida no frontend ou rota visual.
- Credenciais administrativas não podem ser colocadas no código, repositório ou documentação.

## 12. Experiência do aluno
Navegação: Início, Meus cursos, Praticar, Minha evolução e Perfil.
- Aula com conteúdo, vídeo, materiais, tutor IA, prática, repertório e avaliação.
- Sequência recomendada com navegação livre nos conteúdos liberados.
- Instrumento físico como centro da prática.
- Ferramentas: violão (acordes, ritmos, dedilhados, cifras); guitarra (braço, escalas, técnicas, timbres e backing tracks); baixo (notas, grooves e subdivisões); teclado (teclado visual, escalas, acordes e inversões); bateria (rudimentos, grooves, metrônomo e leitura rítmica).

## 13. Professor IA
Tutor de apoio integrado à aula e em área independente. Pode explicar, responder dúvidas, propor exercícios de estudo e orientar a prática com base no currículo publicado. Não pode aprovar avaliações, certificar domínio, alterar currículo oficial ou substituir decisão docente.

## 14. Vídeos e materiais
Modelo híbrido: vídeos próprios e externos selecionados/revisados. Materiais: PDFs, diagramas, ilustrações, áudios, partituras, tablaturas, backing tracks e exercícios. Respeitar direitos autorais; usar conteúdo próprio, licenciado ou legalmente disponível.

## 15. Acompanhamento e diário
Separar:
- tempo de uso do aplicativo;
- tempo de prática autodeclarado;
- atividades e exercícios concluídos;
- evidências enviadas;
- feedback e tentativas;
- competências aprovadas.
Tracking automático + diário manual. Autoavaliação do aluno e acompanhamento docente.

## 16. Notificações
Canais: dentro do app, push e e-mail. Eventos: novas aulas, progresso, tarefas, avaliações, feedback, certificados, conta e eventos relevantes. Incluir preferências por canal, horário de silêncio, agrupamento, histórico e consentimento para push. Professor principal recebe alertas de matrículas e avaliações pendentes.

## 17. Comunidade
Comunidade geral para alunos matriculados; grupos por instrumento e temas (teoria, composição, repertório, técnica e prática); discussões vinculadas às aulas; mensagens privadas.
Professor principal modera globalmente; professores adicionais moderam grupos atribuídos. Denúncia, remoção, suspensão, anti-spam e controles de envio. Comunidade não altera registros oficiais de domínio. Prever salvaguardas para menores, privacidade e participação de responsáveis conforme a legislação.

## 18. Conquistas
Galeria no perfil com medalhas, certificados e marcos. Conquistas automáticas por metas e prática; certificado acadêmico depende de conclusão e aprovação docente. Evitar competição artificial e pontuação sem valor pedagógico.

## 19. Arquitetura técnica alvo
Base existente identificada: React 19, TypeScript, Tailwind v4, Vite e PWA. A matriz nova deve ser uma camada modular, sem substituir o aplicativo inteiro.

Domínios recomendados:
- identity/access: autenticação, perfis, papéis e atribuições.
- academy/catalog: instrumentos, cursos, níveis, módulos e aulas.
- learning/progress: matrícula, desbloqueios e progresso por curso.
- pedagogy/skills: competências e evidências.
- assessment: submissões, tentativas, rubricas e feedback.
- certification: emissão e validação.
- practice: diário, sessões e ferramentas.
- community: grupos, posts, comentários, mensagens e moderação.
- notifications: preferências, eventos e entrega.
- ai-tutor: tutor com escopo limitado ao conteúdo aprovado.

Persistência: manter contratos e IDs estáveis. Firebase/Firestore e regras de segurança devem ser auditados antes de definir coleções finais. Não colocar segredos no cliente. Operações sensíveis devem ser validadas por backend ou regras de segurança robustas.

## 20. Regras de preservação do projeto atual
- Não sobrescrever `App.tsx` como primeiro passo.
- Não apagar `curriculum.ts`, `soloCourse.ts`, `violaoCourse.ts` ou serviços existentes.
- Não migrar dados sem backup, plano de migração e validação.
- Auditar tipos atuais, armazenamento local, autenticação, testes e integrações.
- Verificar base path do GitHub Pages (`/Guitar-Academy/`) em todos os builds.
- Integrar em branch isolada e executar lint, testes e build.
- Toda mudança deve ter escopo pequeno, rollback e critérios de aceite.

## 21. Fases de execução
1. Especificação mestre e inventário da base atual.
2. Modelo de domínio e catálogo curricular.
3. Matriz completa de disciplinas, pré-requisitos e rubricas.
4. Compatibilidade com cursos e progresso existentes.
5. Identidade, matrícula e permissões.
6. Avaliações, evidências e certificação.
7. Comunidade e notificações.
8. Integração do tutor IA.
9. UX responsiva e acessibilidade.
10. Auditoria, testes, migração e lançamento gradual.

## 22. Critério de verdade
Este documento é a referência de produto e pedagogia. O código implementa estas regras, mas não pode redefinir silenciosamente decisões acadêmicas. Mudanças devem ser versionadas e justificadas.
