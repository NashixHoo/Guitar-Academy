# Camada Academy — matriz central

Esta pasta contém a primeira fundação tipada do domínio acadêmico, isolada do `App.tsx` e dos serviços atuais.

## Arquivos
- `core/types.ts`: contratos do domínio.
- `core/config.ts`: decisões de produto e catálogo de instrumentos/níveis.
- `curriculum/matrix.ts`: matriz inicial de cinco instrumentos × seis níveis × seis módulos.
- `pedagogy/assessment-model.md`: regras de avaliação prática.

## Estado
A matriz está em `draft`. Ela não deve ser conectada à navegação, ao progresso do aluno ou ao Firebase até passar por:
1. revisão pedagógica por instrumento;
2. revisão de pré-requisitos e competências;
3. revisão técnica dos contratos existentes;
4. testes de integridade e compatibilidade.

## Integração futura
Importar a matriz em um adaptador de catálogo, sem substituir os currículos atuais. Criar migração explícita para IDs/progresso somente após inventário e backup.
