import type { CurriculumLevel, InstrumentCurriculum, InstrumentId, LevelId } from '../core/types';

/** Matriz acadêmica inicial. Conteúdo em estado draft até revisão e aprovação docente. */
const LEVEL_LABELS = [
  "Fundamentos",
  "Iniciação",
  "Desenvolvimento básico",
  "Intermediário",
  "Avançado",
  "Especialização e performance"
] as const;

const RAW_MATRIX = {
  "violao": {
    "0": [
      "Fundamentos do instrumento e da linguagem musical",
      [
        "Anatomia e ergonomia",
        "Afinação e manutenção básica",
        "Ataque, cordas soltas e clareza",
        "Pulsação, compasso e subdivisão",
        "Notas, cifras e leitura inicial",
        "Primeiras sequências e acompanhamento"
      ]
    ],
    "1": [
      "Execução de músicas simples com segurança",
      [
        "Acordes abertos essenciais",
        "Trocas e mudanças harmônicas",
        "Batidas e ritmos fundamentais",
        "Dedilhados iniciais",
        "Cifras e acompanhamento",
        "Repertório inicial completo"
      ]
    ],
    "2": [
      "Consolidar harmonia e acompanhamento",
      [
        "Escala maior e campo harmônico",
        "Tríades, pestana e inversões",
        "Ritmos brasileiros e populares",
        "Arpejos e independência",
        "Escalas e melodias",
        "Transposição e repertório"
      ]
    ],
    "3": [
      "Integrar harmonia, técnica e interpretação",
      [
        "Campo menor, funções e cadências",
        "Tétrades, sus, add9 e tensões",
        "Condução de vozes e baixos alternados",
        "Escalas e improvisação",
        "Fingerstyle e dinâmica",
        "Arranjos e repertório"
      ]
    ],
    "4": [
      "Domínio harmônico, técnico e interpretativo",
      [
        "Harmonia avançada e dominantes",
        "Rearmonização e substituições",
        "Fingerstyle avançado e contraponto",
        "Acompanhamento complexo",
        "Improvisação aplicada",
        "Arranjos, modulações e interpretação"
      ]
    ],
    "5": [
      "Identidade artística e performance solo",
      [
        "Composição e harmonia autoral",
        "Arranjos solo e contraponto",
        "Improvisação de especialização",
        "Identidade interpretativa",
        "Produção e preparação de repertório",
        "Performance e projeto de conclusão"
      ]
    ]
  },
  "guitarra": {
    "0": [
      "Fundamentos da guitarra elétrica e do sinal",
      [
        "Componentes e ergonomia",
        "Cabo, amplificador e cadeia de sinal",
        "Afinação e cuidados",
        "Palheta e ataque",
        "Pulsação, notas e tablatura",
        "Primeiras frases e riffs"
      ]
    ],
    "1": [
      "Técnica inicial e repertório básico",
      [
        "Palhetada alternada",
        "Coordenação entre mãos",
        "Riffs e melodias",
        "Power chords",
        "Timbre, dinâmica e ruído",
        "Músicas iniciais"
      ]
    ],
    "2": [
      "Pentatônica, articulação e improvisação inicial",
      [
        "Pentatônica e posição inicial",
        "Bends, vibrato e slides",
        "Riffs e power chords",
        "Hammer-on, pull-off e legato",
        "Fraseado e pausas",
        "Improvisação inicial"
      ]
    ],
    "3": [
      "Integração de harmonia, técnica e improvisação",
      [
        "Intervalos e escalas",
        "Campo harmônico e funções",
        "Pentatônica em cinco posições",
        "Modos gregos aplicados",
        "Técnica e articulação",
        "Improvisação e composição"
      ]
    ],
    "4": [
      "Técnica avançada e linguagem estilística",
      [
        "Alternate e economy picking",
        "Legato e articulação avançada",
        "Sweep picking e tapping",
        "Arpejos, modos e harmonia",
        "Improvisação sobre mudanças",
        "Timbre, efeitos e interpretação"
      ]
    ],
    "5": [
      "Identidade sonora e performance instrumental",
      [
        "Linguagem e vocabulário autoral",
        "Improvisação de especialização",
        "Técnica de alta performance",
        "Composição instrumental",
        "Timbre, gravação e produção",
        "Performance e projeto autoral"
      ]
    ]
  },
  "baixo": {
    "0": [
      "Fundamentos do instrumento e função musical",
      [
        "Anatomia e ergonomia",
        "Afinação e cuidados",
        "Dedilhado alternado e palheta",
        "Pulsação e subdivisão",
        "Notas e localização no braço",
        "Primeiras linhas e acompanhamento"
      ]
    ],
    "1": [
      "Linhas simples e estabilidade rítmica",
      [
        "Técnica de mão direita",
        "Notas naturais e acidentes",
        "Figuras e pausas",
        "Escalas iniciais",
        "Fundamentais e acompanhamento",
        "Repertório inicial"
      ]
    ],
    "2": [
      "Construção de linhas e domínio de groove",
      [
        "Escalas maiores e menores",
        "Arpejos e tríades",
        "Fundamentais e aproximações",
        "Síncopes e subdivisões",
        "Articulação e dinâmica",
        "Repertório estilístico"
      ]
    ],
    "3": [
      "Harmonia funcional e interação com bateria",
      [
        "Intervalos e funções",
        "Tríades, tétrades e inversões",
        "Cromatismos e condução",
        "Groove e antecipações",
        "Linguagens estilísticas",
        "Criação de linhas e improvisação"
      ]
    ],
    "4": [
      "Vocabulário avançado e condução harmônica",
      [
        "Harmonia e tensões",
        "Voice leading e cromatismos",
        "Polirritmia e groove avançado",
        "Slap, tapping e ghost notes",
        "Walking, funk, fusion e brasileiro",
        "Arranjos e interação de banda"
      ]
    ],
    "5": [
      "Identidade de baixista e performance",
      [
        "Harmonia especializada",
        "Walking bass e solos",
        "Técnicas avançadas combinadas",
        "Composição de linhas",
        "Performance em conjunto",
        "Gravação, timbre e projeto final"
      ]
    ]
  },
  "teclado": {
    "0": [
      "Fundamentos da geografia musical e execução",
      [
        "Teclas, oitavas e controles",
        "Postura e ergonomia",
        "Notas brancas e pretas",
        "Dedilhado e coordenação",
        "Tons, semitons e pulsação",
        "Primeiras melodias"
      ]
    ],
    "1": [
      "Leitura inicial, escalas e acompanhamento",
      [
        "Numeração e dedilhado",
        "Escalas maiores",
        "Tríades maiores e menores",
        "Acordes básicos",
        "Acompanhamento inicial",
        "Repertório simples"
      ]
    ],
    "2": [
      "Harmonia tonal e coordenação das mãos",
      [
        "Campo harmônico maior",
        "Inversões de tríades",
        "Independência das mãos",
        "Baixo, acordes e arpejos",
        "Escala menor natural",
        "Repertório e andamento"
      ]
    ],
    "3": [
      "Harmonia funcional e arranjo",
      [
        "Funções e cadências",
        "Tétrades e inversões",
        "Tensões 9, 11 e 13",
        "Voicings e arpejos",
        "Leitura e cifras",
        "Arranjos e improvisação"
      ]
    ],
    "4": [
      "Harmonia expandida e rearmonização",
      [
        "Acordes complexos e tensões",
        "Voicings avançados e condução",
        "Rearmonização e modulação",
        "Independência e polifonia",
        "Improvisação harmônica",
        "Arranjos, texturas e transições"
      ]
    ],
    "5": [
      "Composição, arranjo e performance",
      [
        "Harmonia contemporânea",
        "Voicings de especialização",
        "Composição e estruturas",
        "Arranjo e orquestração",
        "Improvisação avançada",
        "Performance e projeto final"
      ]
    ]
  },
  "bateria": {
    "0": [
      "Fundamentos de postura, baquetas e pulso",
      [
        "Peças do kit e ergonomia",
        "Pegada e controle de baquetas",
        "Ataques, rebote e alternância",
        "Pulsação e contagem",
        "Coordenação inicial",
        "Primeiro groove"
      ]
    ],
    "1": [
      "Coordenação e repertório básico",
      [
        "Single e double stroke",
        "Coordenação mãos e pés",
        "Grooves básicos",
        "Variações de chimbal",
        "Viradas simples",
        "Primeiras músicas"
      ]
    ],
    "2": [
      "Consolidação de rudimentos e grooves",
      [
        "Paradiddle e rudimentos",
        "Colcheias, semicolcheias e pausas",
        "Independência dos membros",
        "Grooves por estilo",
        "Viradas e transições",
        "Repertório completo"
      ]
    ],
    "3": [
      "Vocabulário rítmico e musicalidade",
      [
        "Independência avançada",
        "Flams, drags e rudimentos",
        "Dinâmica e ghost notes",
        "Compassos compostos e métricas",
        "Estilos e linguagem",
        "Improvisação e interação"
      ]
    ],
    "4": [
      "Controle avançado e linguagem estilística",
      [
        "Rudimentos aplicados ao kit",
        "Independência complexa",
        "Polirritmia e métricas",
        "Acentos e dinâmica avançada",
        "Jazz, fusion, gospel e brasileiro",
        "Improvisação e construção de frases"
      ]
    ],
    "5": [
      "Identidade rítmica e performance",
      [
        "Vocabulário e métricas complexas",
        "Técnica especializada",
        "Improvisação e solos",
        "Composição rítmica",
        "Performance em conjunto",
        "Gravação e projeto final"
      ]
    ]
  }
} as const;

function buildInstrument(instrumentId: InstrumentId): InstrumentCurriculum {
  const raw = RAW_MATRIX[instrumentId];
  const levels = LEVEL_LABELS.map((title, index) => {
    const entry = raw[index as keyof typeof raw];
    const [outcome, moduleTitles] = entry;
    const levelId = index as LevelId;
    const modules = moduleTitles.map((moduleTitle, moduleIndex) => ({
      id: `${instrumentId}-l${levelId}-m${moduleIndex + 1}`,
      title: moduleTitle,
      summary: `Conteúdo de ${moduleTitle.toLowerCase()} no nível ${levelId} de ${instrumentId}.`,
      topics: [moduleTitle],
      prerequisites: [], // preencher após validação formal da progressão e dos IDs de competências
      competencyIds: [`${instrumentId}-l${levelId}-m${moduleIndex + 1}-competency`],
    }));
    const level: CurriculumLevel = {
      id: levelId,
      title: `${levelId} — ${title}`,
      outcome,
      modules,
      finalPracticalChallenge: `Projeto prático de nível ${levelId}: demonstrar os conteúdos essenciais de ${instrumentId} em repertório e execução musical.`,
      assessmentDimensions: ['Técnica instrumental', 'Ritmo e precisão', 'Percepção e leitura', 'Aplicação musical', 'Autonomia e interpretação'],
    };
    return level;
  });
  return { instrumentId, levels, version: '1.0.0-draft', status: 'draft' };
}

export const CURRICULUM_MATRIX: Record<InstrumentId, InstrumentCurriculum> = {
  violao: buildInstrument('violao'),
  guitarra: buildInstrument('guitarra'),
  baixo: buildInstrument('baixo'),
  teclado: buildInstrument('teclado'),
  bateria: buildInstrument('bateria'),
};

export const getInstrumentCurriculum = (id: InstrumentId) => CURRICULUM_MATRIX[id];
export const getLevelCurriculum = (instrumentId: InstrumentId, levelId: LevelId) =>
  CURRICULUM_MATRIX[instrumentId].levels.find((level) => level.id === levelId);
