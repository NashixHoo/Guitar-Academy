# Modelo de avaliação prática — Guitar Academy

## Regra central
Avaliação oficial é prática. Teoria é ensinada, discutida e aplicada por meio da execução, leitura, escuta, análise musical e criação. Provas escritas não são requisito de aprovação.

## Evidências
- Áudio gravado.
- Vídeo gravado.
- Arquivo previamente gravado, quando aplicável.

## Rubrica mínima
Cada avaliação deve declarar:
- competência e resultado observável;
- instrumento e nível;
- tarefa/repertório;
- critérios e pesos;
- evidência exigida;
- condições de execução (andamento, tonalidade, duração, recursos permitidos);
- padrão mínimo de aprovação;
- feedback e plano de recuperação.

## Dimensões comuns
Técnica, ritmo, precisão, musicalidade, aplicação teórica, repertório, autonomia. Pesos e descritores devem ser específicos por competência e instrumento.

## Fluxo
Preparação → envio → análise docente → aprovação ou correção → feedback → nova tentativa. O histórico nunca deve ser apagado por uma nova tentativa.

## Separação de conceitos
- Conclusão de aula: atividade pedagógica concluída.
- Progresso: atividades obrigatórias efetivamente concluídas.
- Domínio: competência aprovada pelo professor.
- Conclusão de nível/curso: todos os requisitos acadêmicos atendidos e aprovação final docente.
