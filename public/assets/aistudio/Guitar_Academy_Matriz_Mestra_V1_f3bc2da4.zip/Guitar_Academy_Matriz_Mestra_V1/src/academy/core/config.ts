import type { InstrumentDefinition, LevelId, UserRole } from './types';

export const ACADEMY_CONFIG = {
  name: 'Guitar Academy',
  locale: 'pt-BR',
  academicDepth: 'conservatory',
  deliveryMode: 'online-first',
  assessmentMode: 'practice-only',
  certificates: {
    perLevel: true,
    finalCourse: true,
    requireTeacherFinalApproval: true,
    publicVerification: true,
  },
  enrollment: {
    autoJoinAcademy: true,
    providers: ['google', 'email-password'] as const,
    unlockOtherInstrumentsAtPercent: 50,
  },
  aiTutor: {
    enabled: true,
    mayApproveCompetencies: false,
    mayIssueCertificates: false,
    mayPublishCurriculum: false,
  },
  community: {
    enabled: true,
    generalGroupForEnrolledStudents: true,
    instrumentGroups: true,
    topicGroups: true,
    privateMessages: true,
  },
  notifications: {
    channels: ['in_app', 'push', 'email'] as const,
    quietHours: true,
    userPreferences: true,
  },
} as const;

export const LEVELS: ReadonlyArray<{ id: LevelId; title: string }> = [
  { id: 0, title: 'Fundamentos' },
  { id: 1, title: 'Iniciação' },
  { id: 2, title: 'Desenvolvimento básico' },
  { id: 3, title: 'Intermediário' },
  { id: 4, title: 'Avançado' },
  { id: 5, title: 'Especialização e performance' },
];

export const INSTRUMENTS: readonly InstrumentDefinition[] = [
  { id: 'violao', name: 'Violão', shortName: 'Violão', description: 'Instrumento acústico de cordas dedilhadas.', tuningOrSetupNote: 'Afinação padrão E-A-D-G-B-E; adaptar conteúdo para nylon e aço.' },
  { id: 'guitarra', name: 'Guitarra', shortName: 'Guitarra', description: 'Instrumento elétrico de cordas com amplificação e processamento de sinal.', tuningOrSetupNote: 'Afinação padrão E-A-D-G-B-E; abordar sinal, amplificação e timbre.' },
  { id: 'baixo', name: 'Baixo', shortName: 'Baixo', description: 'Instrumento de função grave e sustentação rítmico-harmônica.', tuningOrSetupNote: 'Baixo de quatro cordas E-A-D-G como referência inicial; extensões documentadas.' },
  { id: 'teclado', name: 'Teclado', shortName: 'Teclado', description: 'Instrumento de teclas para harmonia, melodia, acompanhamento e arranjo.', tuningOrSetupNote: 'Geografia do teclado, dedilhado, registros, timbres e pedal quando aplicável.' },
  { id: 'bateria', name: 'Bateria', shortName: 'Bateria', description: 'Instrumento de percussão para organização rítmica, dinâmica e interação.', tuningOrSetupNote: 'Kit acústico ou eletrônico; postura, baquetas, afinação e dinâmica.' },
];

export const ROLE_HIERARCHY: Record<UserRole, number> = {
  student: 1,
  teacher: 2,
  head_teacher: 3,
};

export const isLevelId = (value: number): value is LevelId =>
  Number.isInteger(value) && value >= 0 && value <= 5;
