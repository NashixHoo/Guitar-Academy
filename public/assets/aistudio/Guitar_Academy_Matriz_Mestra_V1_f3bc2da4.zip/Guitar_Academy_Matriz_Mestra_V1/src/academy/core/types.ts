/**
 * Guitar Academy — domínio acadêmico central.
 * Tipos puros: não dependem de React, Firebase ou da UI.
 */

export type InstrumentId = 'violao' | 'guitarra' | 'baixo' | 'teclado' | 'bateria';
export type LevelId = 0 | 1 | 2 | 3 | 4 | 5;
export type UserRole = 'student' | 'teacher' | 'head_teacher';

export type CompetencyStatus =
  | 'not_started'
  | 'in_progress'
  | 'awaiting_assessment'
  | 'needs_correction'
  | 'mastered';

export type AssessmentStatus =
  | 'not_started'
  | 'preparing'
  | 'submitted'
  | 'under_review'
  | 'approved'
  | 'needs_correction'
  | 'resubmitted';

export type EvidenceKind = 'audio' | 'video' | 'file';
export type FeedbackKind = 'text' | 'audio' | 'video';

export interface InstrumentDefinition {
  id: InstrumentId;
  name: string;
  shortName: string;
  description: string;
  tuningOrSetupNote: string;
}

export interface CurriculumModule {
  id: string;
  title: string;
  summary: string;
  topics: string[];
  prerequisites: string[];
  competencyIds: string[];
  suggestedMinutes?: number;
}

export interface CurriculumLevel {
  id: LevelId;
  title: string;
  outcome: string;
  modules: CurriculumModule[];
  finalPracticalChallenge: string;
  assessmentDimensions: string[];
}

export interface InstrumentCurriculum {
  instrumentId: InstrumentId;
  levels: CurriculumLevel[];
  version: string;
  status: 'draft' | 'review' | 'approved' | 'published';
}

export interface CompetencyDefinition {
  id: string;
  instrumentId: InstrumentId;
  level: LevelId;
  title: string;
  observableOutcome: string;
  evidenceRequirements: string[];
  rubricId: string;
}

export interface AssessmentRubricCriterion {
  id: string;
  name: string;
  description: string;
  weight: number;
  performanceAnchors: {
    needsCorrection: string;
    developing: string;
    mastered: string;
  };
}

export interface AssessmentRubric {
  id: string;
  instrumentId: InstrumentId;
  level: LevelId;
  competencyId: string;
  criteria: AssessmentRubricCriterion[];
  approvalRule: string;
}

export interface StudentCourseProgress {
  studentId: string;
  instrumentId: InstrumentId;
  courseProgressPercent: number;
  completedLessonIds: string[];
  completedRequiredActivityIds: string[];
  competencyStatuses: Record<string, CompetencyStatus>;
  updatedAt: string;
}

export interface AssessmentSubmission {
  id: string;
  studentId: string;
  instrumentId: InstrumentId;
  level: LevelId;
  competencyId: string;
  status: AssessmentStatus;
  evidence: Array<{
    kind: EvidenceKind;
    storageRef: string;
    createdAt: string;
  }>;
  attempts: number;
  teacherId?: string;
  feedback?: Array<{
    kind: FeedbackKind;
    storageRefOrText: string;
    createdAt: string;
  }>;
}

export interface CertificateRecord {
  id: string;
  studentId: string;
  instrumentId: InstrumentId;
  kind: 'level' | 'course';
  level?: LevelId;
  verificationCode: string;
  issuedAt: string;
  issuedBy: string;
  status: 'valid' | 'revoked';
}

/** Guard: 50% válido libera outros instrumentos; não equivale a domínio acadêmico. */
export interface CourseUnlockPolicy {
  thresholdPercent: 50;
  countsCompletedRequiredLessons: true;
  countsCompletedRequiredActivities: true;
  requiresTeacherApprovalForEveryLesson: false;
}
