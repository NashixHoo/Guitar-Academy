# Integração técnica

## Estrutura atual identificada
O projeto já possui um sistema de mídia:
- `src/data/visualGallery.ts`
- `src/data/courseLessonVisuals.ts`
- `src/components/common/IllustrativeCard.tsx`
- `src/components/curriculum/LessonViewer.tsx`
- `src/components/curriculum/CourseVisualBanner.tsx`

`getLessonVisual(lesson)` já associa uma imagem a cada aula por instrumento e palavras-chave. Portanto, a integração correta é ampliar esse mapeamento com imagens tecnicamente adequadas, não criar um segundo sistema de mídia.

## O que este pacote contém
- Imagem editorial de um músico tocando violão em estúdio.
- Duas colagens de referência geral de recursos do aplicativo.
- Tons sintetizados de referência para cordas de violão/guitarra, baixo e teclado.
- Metrônomos sintetizados de 60, 80 e 100 BPM.
- Um arpejo sintetizado de Dó maior.
- Três vídeos editoriais curtos gerados a partir de imagens estáticas com movimento de câmera.

## Limitações de conteúdo
Os tons WAV são sinais sintetizados, não gravações de instrumentos reais. Os vídeos MP4 são vídeos editoriais de apresentação, não demonstrações reais de postura, dedilhado, palhetada, slap, voicings ou rudimentos. As colagens são referências visuais gerais e não devem substituir diagramas técnicos validados.

## Caminho recomendado
1. Descompactar o pacote.
2. Copiar imagens para `src/assets/images/guitar-academy-media-pack/`.
3. Executar o prompt `PROMPT_AI_STUDIO.txt` no AI Studio com o pacote disponível.
4. Validar visualmente o app publicado depois do deploy.
