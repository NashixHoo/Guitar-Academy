# Guitar Academy — Pacote completo de mídia

## Conteúdo
Os arquivos estão individualizados e organizados por assunto:
- `01-home`: imagens gerais e editoriais da área inicial
- `02-violao`: referência de execução e diagramas de violão
- `03-guitarra`: mapas de notas e escala pentatônica
- `04-baixo`: afinação padrão
- `05-teclado`: escala e tríade
- `06-bateria`: mapa do kit
- `07-teoria`: pauta, ritmo e campo harmônico
- `08-tecnicas`: referência editorial de postura
- `09-videos`: vídeos editoriais MP4 e imagens de capa
- `10-audios`: tons sintetizados, metrônomos e arpejo
- `11-integracao`: instruções e prompt para o Google AI Studio
- `12-paineis-visuais`: painéis e imagens promocionais adicionais
- `13-documentacao`: documentação complementar

## Como usar
1. Descompacte o ZIP.
2. Disponibilize a pasta extraída no contexto do projeto no Google AI Studio.
3. Abra `11-integracao/PROMPT_PARA_AI_STUDIO.txt`.
4. Copie o conteúdo integral e envie ao AI Studio junto com os arquivos do pacote.
5. Revise o relatório antes de sincronizar com o GitHub.

## Limitações importantes
- WAVs são sons sintetizados, não gravações reais de instrumentos.
- MP4s são vídeos editoriais com movimento sobre imagens estáticas, não demonstrações de professor.
- Painéis e colagens são imagens editoriais, não diagramas técnicos.
- A referência de postura não substitui uma demonstração validada por professor.

O pacote não autoriza alterações em autenticação, Firebase, Firestore, regras, cursos, IDs, progresso, pagamentos ou rotas.
