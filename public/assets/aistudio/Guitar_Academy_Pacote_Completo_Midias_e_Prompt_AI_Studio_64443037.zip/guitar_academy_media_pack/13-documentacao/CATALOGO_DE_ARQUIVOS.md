# Catálogo de arquivos de mídia

## 01-home
- `01-home/media_overview_01.png`
- `01-home/media_overview_02.png`
- `01-home/painel_visual_referencia_cursos.png`
- `01-home/studio_guitarist.png`

## 02-violao
- `02-violao/01_afinação_padrao_cordas_soltas.png`
- `02-violao/02_acorde_C_maior.png`
- `02-violao/03_acorde_G_maior.png`
- `02-violao/04_acorde_D_maior.png`
- `02-violao/violao_referencia_execucao_estudio.png`

## 03-guitarra
- `03-guitarra/01_mapa_notas_naturais_casas_0_a_5.png`
- `03-guitarra/02_pentatonica_mi_menor_box1.png`

## 04-baixo
- `04-baixo/01_afinação_padrao_baixo_4_cordas.png`

## 05-teclado
- `05-teclado/01_teclas_escala_do_maior.png`
- `05-teclado/02_triade_do_maior.png`

## 06-bateria
- `06-bateria/01_mapa_kit_bateria_vista_superior.png`

## 07-teoria
- `07-teoria/01_escala_do_maior_pauta_clave_sol.png`
- `07-teoria/02_valores_ritmicos_4_4.png`
- `07-teoria/03_campo_harmonico_do_maior.png`
- `07-teoria/visao_geral_didatica_conceitual.png`

## 08-tecnicas
- `08-tecnicas/referencia_postura_execucao_violao.png`

## 09-videos
- `09-videos/01_apresentacao_guitar_academy.jpg`
- `09-videos/01_apresentacao_guitar_academy.mp4`
- `09-videos/02_visao_geral_dos_recursos.jpg`
- `09-videos/02_visao_geral_dos_recursos.mp4`
- `09-videos/03_jornada_de_formacao.jpg`
- `09-videos/03_jornada_de_formacao.mp4`

## 10-audios
- `10-audios/arpejo_Dó_maior_C4_E4_G4_C5.wav`
- `10-audios/baixo_1a_G2_98Hz.wav`
- `10-audios/baixo_2a_D2_73-42Hz.wav`
- `10-audios/baixo_3a_A1_55Hz.wav`
- `10-audios/baixo_4a_E1_41-20Hz.wav`
- `10-audios/metronomo_100bpm_30s.wav`
- `10-audios/metronomo_60bpm_30s.wav`
- `10-audios/metronomo_80bpm_30s.wav`
- `10-audios/teclado_A4_440Hz.wav`
- `10-audios/teclado_C4_261-63Hz.wav`
- `10-audios/violao_guitarra_1a_E4_329-63Hz.wav`
- `10-audios/violao_guitarra_2a_B3_246-94Hz.wav`
- `10-audios/violao_guitarra_3a_G3_196Hz.wav`
- `10-audios/violao_guitarra_4a_D3_146-83Hz.wav`
- `10-audios/violao_guitarra_5a_A2_110Hz.wav`
- `10-audios/violao_guitarra_6a_E2_82-41Hz.wav`

## 12-paineis-visuais
- `12-paineis-visuais/ambiente_estudio_musical.png`
- `12-paineis-visuais/banner_visual_guitar_academy.png`
- `12-paineis-visuais/painel_educacional_visao_geral.png`
- `12-paineis-visuais/painel_promocional_grade_cursos.png`
